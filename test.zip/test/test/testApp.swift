//
//  testApp.swift
//  test

import SwiftUI
import Firebase
import GoogleSignIn

//class AppDelegate: UIResponder, UIApplicationDelegate {
//  func application(_ application: UIApplication,
//                   didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey : Any]?) -> Bool {
//    FirebaseApp.configure()
//    return true
//  }
//}

@main
struct testApp: App {
    
    init() {
        FirebaseApp.configure()
    }
    
    func application(_ app: UIApplication,
                     open url: URL,
                     options: [UIApplication.OpenURLOptionsKey: Any] = [:]) -> Bool {
      return GIDSignIn.sharedInstance.handle(url)
    }
    
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
